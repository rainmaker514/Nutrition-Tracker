package com.nutritiontracker.NutritionTrackerUserService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NutritionTrackerUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NutritionTrackerUserServiceApplication.class, args);
	}

}
